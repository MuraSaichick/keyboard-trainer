/****************************************************************************
** Meta object code from reading C++ file 'thememanager.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.8.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../thememanager.h"
#include <QtCore/qmetatype.h>

#include <QtCore/qtmochelpers.h>

#include <memory>


#include <QtCore/qxptype_traits.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'thememanager.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.8.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {
struct qt_meta_tag_ZN12ThemeManagerE_t {};
} // unnamed namespace


#ifdef QT_MOC_HAS_STRINGDATA
static constexpr auto qt_meta_stringdata_ZN12ThemeManagerE = QtMocHelpers::stringData(
    "ThemeManager",
    "themeChanged",
    "",
    "colorsChanged",
    "setTheme",
    "theme",
    "background",
    "text",
    "button",
    "border",
    "figure",
    "placeHolderText",
    "inputBackground",
    "buttonHoverColor",
    "inputTextColor",
    "highlight",
    "highlightedText"
);
#else  // !QT_MOC_HAS_STRINGDATA
#error "qtmochelpers.h not found or too old."
#endif // !QT_MOC_HAS_STRINGDATA

Q_CONSTINIT static const uint qt_meta_data_ZN12ThemeManagerE[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
       3,   14, // methods
      12,   37, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   32,    2, 0x06,   13 /* Public */,
       3,    0,   33,    2, 0x06,   14 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       4,    1,   34,    2, 0x0a,   15 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,    5,

 // properties: name, type, flags, notifyId, revision
       5, QMetaType::QString, 0x00015103, uint(0), 0,
       6, QMetaType::QColor, 0x00015001, uint(1), 0,
       7, QMetaType::QColor, 0x00015001, uint(1), 0,
       8, QMetaType::QColor, 0x00015001, uint(1), 0,
       9, QMetaType::QColor, 0x00015001, uint(1), 0,
      10, QMetaType::QColor, 0x00015001, uint(1), 0,
      11, QMetaType::QColor, 0x00015001, uint(1), 0,
      12, QMetaType::QColor, 0x00015001, uint(1), 0,
      13, QMetaType::QColor, 0x00015001, uint(1), 0,
      14, QMetaType::QColor, 0x00015001, uint(1), 0,
      15, QMetaType::QColor, 0x00015001, uint(1), 0,
      16, QMetaType::QColor, 0x00015001, uint(1), 0,

       0        // eod
};

Q_CONSTINIT const QMetaObject ThemeManager::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_ZN12ThemeManagerE.offsetsAndSizes,
    qt_meta_data_ZN12ThemeManagerE,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_tag_ZN12ThemeManagerE_t,
        // property 'theme'
        QtPrivate::TypeAndForceComplete<QString, std::true_type>,
        // property 'background'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'text'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'button'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'border'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'figure'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'placeHolderText'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'inputBackground'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'buttonHoverColor'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'inputTextColor'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'highlight'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'highlightedText'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<ThemeManager, std::true_type>,
        // method 'themeChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'colorsChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setTheme'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>
    >,
    nullptr
} };

void ThemeManager::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    auto *_t = static_cast<ThemeManager *>(_o);
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: _t->themeChanged(); break;
        case 1: _t->colorsChanged(); break;
        case 2: _t->setTheme((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        default: ;
        }
    }
    if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _q_method_type = void (ThemeManager::*)();
            if (_q_method_type _q_method = &ThemeManager::themeChanged; *reinterpret_cast<_q_method_type *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _q_method_type = void (ThemeManager::*)();
            if (_q_method_type _q_method = &ThemeManager::colorsChanged; *reinterpret_cast<_q_method_type *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
    }
    if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QString*>(_v) = _t->theme(); break;
        case 1: *reinterpret_cast< QColor*>(_v) = _t->background(); break;
        case 2: *reinterpret_cast< QColor*>(_v) = _t->text(); break;
        case 3: *reinterpret_cast< QColor*>(_v) = _t->button(); break;
        case 4: *reinterpret_cast< QColor*>(_v) = _t->border(); break;
        case 5: *reinterpret_cast< QColor*>(_v) = _t->figure(); break;
        case 6: *reinterpret_cast< QColor*>(_v) = _t->placeHolderText(); break;
        case 7: *reinterpret_cast< QColor*>(_v) = _t->inputBackground(); break;
        case 8: *reinterpret_cast< QColor*>(_v) = _t->buttonHoverColor(); break;
        case 9: *reinterpret_cast< QColor*>(_v) = _t->inputTextColor(); break;
        case 10: *reinterpret_cast< QColor*>(_v) = _t->highlight(); break;
        case 11: *reinterpret_cast< QColor*>(_v) = _t->highlightedText(); break;
        default: break;
        }
    }
    if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setTheme(*reinterpret_cast< QString*>(_v)); break;
        default: break;
        }
    }
}

const QMetaObject *ThemeManager::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ThemeManager::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_ZN12ThemeManagerE.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int ThemeManager::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 3)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 3;
    }
    if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 3)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 3;
    }
    if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::BindableProperty
            || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    }
    return _id;
}

// SIGNAL 0
void ThemeManager::themeChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void ThemeManager::colorsChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}
QT_WARNING_POP
