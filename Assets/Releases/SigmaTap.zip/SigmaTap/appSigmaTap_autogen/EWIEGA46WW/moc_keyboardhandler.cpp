/****************************************************************************
** Meta object code from reading C++ file 'keyboardhandler.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.8.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../keyboardhandler.h"
#include <QtCore/qmetatype.h>

#include <QtCore/qtmochelpers.h>

#include <memory>


#include <QtCore/qxptype_traits.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'keyboardhandler.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.8.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {
struct qt_meta_tag_ZN15KeyboardHandlerE_t {};
} // unnamed namespace


#ifdef QT_MOC_HAS_STRINGDATA
static constexpr auto qt_meta_stringdata_ZN15KeyboardHandlerE = QtMocHelpers::stringData(
    "KeyboardHandler",
    "textChanged",
    "",
    "isMethodLockedChanged",
    "cursorChanged",
    "x",
    "scrollChanged",
    "scrollHorizontalRequested",
    "offset",
    "enteredWordsChanged",
    "textEntryCompleted",
    "setEnteredWords",
    "enteredWords",
    "setIsMethodLocked",
    "newMethod",
    "setTextWidth",
    "width",
    "setOriginalString",
    "original",
    "setModifiedString",
    "modified",
    "startPositionLater",
    "inputCharacter",
    "character",
    "getModifiedString",
    "getX",
    "getY",
    "getEnteredWords",
    "getFontSize",
    "getFontFamily",
    "getLineSpacingText",
    "getCorrectKeyCount",
    "getPressAccuracy",
    "setPosition",
    "y",
    "setFontSize",
    "size",
    "setFontFamily",
    "family",
    "setFontLetterSpacing",
    "letterSpacing",
    "self",
    "KeyboardHandler*",
    "setIsVertical",
    "isVertical",
    "isMethodLocked"
);
#else  // !QT_MOC_HAS_STRINGDATA
#error "qtmochelpers.h not found or too old."
#endif // !QT_MOC_HAS_STRINGDATA

Q_CONSTINIT static const uint qt_meta_data_ZN15KeyboardHandlerE[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
      29,   14, // methods
       1,  245, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       7,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  188,    2, 0x06,    2 /* Public */,
       3,    0,  189,    2, 0x06,    3 /* Public */,
       4,    1,  190,    2, 0x06,    4 /* Public */,
       6,    0,  193,    2, 0x06,    6 /* Public */,
       7,    1,  194,    2, 0x06,    7 /* Public */,
       9,    0,  197,    2, 0x06,    9 /* Public */,
      10,    0,  198,    2, 0x06,   10 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
      11,    1,  199,    2, 0x0a,   11 /* Public */,
      13,    1,  202,    2, 0x0a,   13 /* Public */,
      15,    1,  205,    2, 0x0a,   15 /* Public */,
      17,    1,  208,    2, 0x0a,   17 /* Public */,
      19,    1,  211,    2, 0x0a,   19 /* Public */,
      21,    0,  214,    2, 0x0a,   21 /* Public */,
      22,    1,  215,    2, 0x0a,   22 /* Public */,
      24,    0,  218,    2, 0x10a,   24 /* Public | MethodIsConst  */,
      25,    0,  219,    2, 0x10a,   25 /* Public | MethodIsConst  */,
      26,    0,  220,    2, 0x10a,   26 /* Public | MethodIsConst  */,
      27,    0,  221,    2, 0x0a,   27 /* Public */,
      28,    0,  222,    2, 0x10a,   28 /* Public | MethodIsConst  */,
      29,    0,  223,    2, 0x10a,   29 /* Public | MethodIsConst  */,
      30,    0,  224,    2, 0x10a,   30 /* Public | MethodIsConst  */,
      31,    0,  225,    2, 0x10a,   31 /* Public | MethodIsConst  */,
      32,    0,  226,    2, 0x0a,   32 /* Public */,

 // methods: name, argc, parameters, tag, flags, initial metatype offsets
      33,    2,  227,    2, 0x02,   33 /* Public */,
      35,    1,  232,    2, 0x02,   36 /* Public */,
      37,    1,  235,    2, 0x02,   38 /* Public */,
      39,    1,  238,    2, 0x02,   40 /* Public */,
      41,    0,  241,    2, 0x02,   42 /* Public */,
      43,    1,  242,    2, 0x02,   43 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    8,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void, QMetaType::Bool,   14,
    QMetaType::Void, QMetaType::Double,   16,
    QMetaType::Void, QMetaType::QString,   18,
    QMetaType::Void, QMetaType::QString,   20,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QChar,   23,
    QMetaType::QString,
    QMetaType::Int,
    QMetaType::Int,
    QMetaType::Int,
    QMetaType::Int,
    QMetaType::QString,
    QMetaType::Int,
    QMetaType::Int,
    QMetaType::Double,

 // methods: parameters
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    5,   34,
    QMetaType::Void, QMetaType::Int,   36,
    QMetaType::Void, QMetaType::QString,   38,
    QMetaType::Void, QMetaType::Int,   40,
    0x80000000 | 42,
    QMetaType::Void, QMetaType::Bool,   44,

 // properties: name, type, flags, notifyId, revision
      45, QMetaType::Bool, 0x00015103, uint(1), 0,

       0        // eod
};

Q_CONSTINIT const QMetaObject KeyboardHandler::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_ZN15KeyboardHandlerE.offsetsAndSizes,
    qt_meta_data_ZN15KeyboardHandlerE,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_tag_ZN15KeyboardHandlerE_t,
        // property 'isMethodLocked'
        QtPrivate::TypeAndForceComplete<bool, std::true_type>,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<KeyboardHandler, std::true_type>,
        // method 'textChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'isMethodLockedChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'cursorChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'scrollChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'scrollHorizontalRequested'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'enteredWordsChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'textEntryCompleted'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setEnteredWords'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'setIsMethodLocked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'setTextWidth'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        // method 'setOriginalString'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'setModifiedString'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'startPositionLater'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'inputCharacter'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QChar, std::false_type>,
        // method 'getModifiedString'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'getX'
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'getY'
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'getEnteredWords'
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'getFontSize'
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'getFontFamily'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'getLineSpacingText'
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'getCorrectKeyCount'
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'getPressAccuracy'
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        // method 'setPosition'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'setFontSize'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'setFontFamily'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'setFontLetterSpacing'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'self'
        QtPrivate::TypeAndForceComplete<KeyboardHandler *, std::false_type>,
        // method 'setIsVertical'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>
    >,
    nullptr
} };

void KeyboardHandler::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    auto *_t = static_cast<KeyboardHandler *>(_o);
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: _t->textChanged(); break;
        case 1: _t->isMethodLockedChanged(); break;
        case 2: _t->cursorChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 3: _t->scrollChanged(); break;
        case 4: _t->scrollHorizontalRequested((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 5: _t->enteredWordsChanged(); break;
        case 6: _t->textEntryCompleted(); break;
        case 7: _t->setEnteredWords((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 8: _t->setIsMethodLocked((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 9: _t->setTextWidth((*reinterpret_cast< std::add_pointer_t<double>>(_a[1]))); break;
        case 10: _t->setOriginalString((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 11: _t->setModifiedString((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 12: _t->startPositionLater(); break;
        case 13: _t->inputCharacter((*reinterpret_cast< std::add_pointer_t<QChar>>(_a[1]))); break;
        case 14: { QString _r = _t->getModifiedString();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 15: { int _r = _t->getX();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 16: { int _r = _t->getY();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 17: { int _r = _t->getEnteredWords();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 18: { int _r = _t->getFontSize();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 19: { QString _r = _t->getFontFamily();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 20: { int _r = _t->getLineSpacingText();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 21: { int _r = _t->getCorrectKeyCount();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 22: { double _r = _t->getPressAccuracy();
            if (_a[0]) *reinterpret_cast< double*>(_a[0]) = std::move(_r); }  break;
        case 23: _t->setPosition((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[2]))); break;
        case 24: _t->setFontSize((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 25: _t->setFontFamily((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 26: _t->setFontLetterSpacing((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 27: { KeyboardHandler* _r = _t->self();
            if (_a[0]) *reinterpret_cast< KeyboardHandler**>(_a[0]) = std::move(_r); }  break;
        case 28: _t->setIsVertical((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        default: ;
        }
    }
    if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _q_method_type = void (KeyboardHandler::*)();
            if (_q_method_type _q_method = &KeyboardHandler::textChanged; *reinterpret_cast<_q_method_type *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _q_method_type = void (KeyboardHandler::*)();
            if (_q_method_type _q_method = &KeyboardHandler::isMethodLockedChanged; *reinterpret_cast<_q_method_type *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _q_method_type = void (KeyboardHandler::*)(int );
            if (_q_method_type _q_method = &KeyboardHandler::cursorChanged; *reinterpret_cast<_q_method_type *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _q_method_type = void (KeyboardHandler::*)();
            if (_q_method_type _q_method = &KeyboardHandler::scrollChanged; *reinterpret_cast<_q_method_type *>(_a[1]) == _q_method) {
                *result = 3;
                return;
            }
        }
        {
            using _q_method_type = void (KeyboardHandler::*)(int );
            if (_q_method_type _q_method = &KeyboardHandler::scrollHorizontalRequested; *reinterpret_cast<_q_method_type *>(_a[1]) == _q_method) {
                *result = 4;
                return;
            }
        }
        {
            using _q_method_type = void (KeyboardHandler::*)();
            if (_q_method_type _q_method = &KeyboardHandler::enteredWordsChanged; *reinterpret_cast<_q_method_type *>(_a[1]) == _q_method) {
                *result = 5;
                return;
            }
        }
        {
            using _q_method_type = void (KeyboardHandler::*)();
            if (_q_method_type _q_method = &KeyboardHandler::textEntryCompleted; *reinterpret_cast<_q_method_type *>(_a[1]) == _q_method) {
                *result = 6;
                return;
            }
        }
    }
    if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< bool*>(_v) = _t->isMethodLocked(); break;
        default: break;
        }
    }
    if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setIsMethodLocked(*reinterpret_cast< bool*>(_v)); break;
        default: break;
        }
    }
}

const QMetaObject *KeyboardHandler::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *KeyboardHandler::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_ZN15KeyboardHandlerE.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int KeyboardHandler::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 29)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 29;
    }
    if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 29)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 29;
    }
    if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::BindableProperty
            || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    }
    return _id;
}

// SIGNAL 0
void KeyboardHandler::textChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void KeyboardHandler::isMethodLockedChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void KeyboardHandler::cursorChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void KeyboardHandler::scrollChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void KeyboardHandler::scrollHorizontalRequested(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void KeyboardHandler::enteredWordsChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void KeyboardHandler::textEntryCompleted()
{
    QMetaObject::activate(this, &staticMetaObject, 6, nullptr);
}
QT_WARNING_POP
